module.exports = {
  crypto: {
    privateKey: "NeverShareYourSecret",
    tokenExpiry: 1 * 30 * 1000 * 60, //1 hour
  },
  auth: {
    password: "password",
  },
};
